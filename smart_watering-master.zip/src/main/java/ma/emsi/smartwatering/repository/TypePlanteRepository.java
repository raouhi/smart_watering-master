package ma.emsi.smartwatering.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.emsi.smartwatering.model.TypePlante;

public interface TypePlanteRepository extends JpaRepository<TypePlante,Long>{

}
